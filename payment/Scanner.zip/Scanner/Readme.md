## MYPAY New Zealand  

**For Alipay and WeChat Pay payment services**

```
Sandbox:
https://sandbox.gateway.mypaynz.com/
Test Account:
U : merchant_test
P : 123456

Test Barcode:
Alipay:
280000000000000014  // SUCCESS
280000000000000015  // USERPAYING
280000000000000016  // ERROR 

Wechat:
280000000000000024  // SUCCESS
280000000000000025  // USERPAYING
280000000000000026  // ERROR 

Tips:
Alipay Barcode almost start with: 28
Wechat Barcode almost start with: 10, 11, 12, 13, 14, 15

Production:
https://mypay.iemoney.co.nz
Test Account:
U : merchant_test
P: 123456
```



