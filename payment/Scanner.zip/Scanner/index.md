## MYPAY New Zealand  

**For Alipay and WeChat Pay payment services**


## OverviewNew Zealand is enjoying an unprecedented relationship with China currently through trade and exports. With the popular rise of Daigous and more and more Chinese nationals having the means to travel and study overseas, our tourism, international education and exports is expanding rapidly. With this economic trend comes a new mobile payment method. Through apps like Alipay and Wechat Pay, Chinese consumers are able to access and spend their Chinese bank account money simply by generating a QR code for a merchant to scan. The merchant then receives local currency in their bank accounts the next day or so.## MYPAYMYPAY is a local Fintech company in New Zealand that has global connections. We pride ourselves in bringing the economic, financial and cultural benefits of a cashless payment system to New Zealand and are also passionate about developing technological tools to make everyday payments easier for New Zealanders. ## AlipayAlipay is China’s leading third party online payment solution. In 2013 it overtook PayPal as the world’s largest mobile payment platform. It currently has a growing database of 520 million users.Alipay operates with all the major banks in China to provide payment services for more than 460,000 online and local Chinese businesses. By connecting the user’s Alipay account with their bank account, users can either spend money directly from that bank account through Alipay or “recharge” their Alipay accounts. Internationally, more than 1000 merchants in New Zealand use Alipay to directly sell to consumers in China. It currently supports transactions in 18 major foreign currencies.## WeChat PayWeChat is the super app of China, with market saturation like none other. It is China’s leading instant messaging app with over 980 million active monthly users. WeChat features include messaging, official accounts, Moments and WeChat Pay. Since 2011, WeChat has become China’s “App for everything”. It now has almost an equal share in the Chinese mobile payment market alongside Alipay. In 2014 for Chinese New Year, WeChat introduced a feature for distributing virtual red envelopes which is modeled after the Chinese tradition of exchanging red money packets between friends and family members during holidays. This feature allows users to send money to contacts and groups as gifts. When sent to groups, the money is distributed equally, or in random shares ("Lucky Money"). Wechat Pay now has a 37% share in the Chinese mobile online payments market for 2017. 

## The Solution
* Integrate MYPAY in-store barcode payment service.
	The barcode payment solution provides the way to pay for an order by scanning the barcode on customers' phone.
	
	 **Process:**
	 
	 
	```
	1. Customer wants to pay for goods at cashier in store. 
	2. Pharmacy staff scans customers' barcode using provided scanner.
	3. System sends a payment request to MYPAY.
	4. MYPAY act as a gateway then sends the payment request to either Alipay or WeChat Pay for authorisation.
	5. Alipay and WeChat Pay process the transaction and sends customer the payment result via SMS or in-app notification.
	6. Alipay and WeChat Pay sends payment result to MYPAY simultaneously.
	7. MYPAY then sends payment result to Merchant via pre-defined notification method.
	```
	

	![](https://s1.ax1x.com/2018/06/12/CLvW8K.jpg)
	![](https://os.alipayobjects.com/rmsportal/LiaHuhOgUobNDbizthCC.png)
	![](https://os.alipayobjects.com/rmsportal/YhxrWdHBHlrbdWsHIaUW.png)
	
## Demo
Please refer to attached file

## API List
#### 1. Paymemnt Interface

##### The gateway URL： https://mypay.iemoney.co.nz/api/pay
##### Request Method: POST

| Parameter | Type   | Nullable | Description |
| --------- | ----   | -------- | ----------- |
| mid       | int(4) | No       | Merchant ID |
| tid       | int(4) | Yes       | Terminal ID |
| fee       | int(10)| No       | amount, unit: cent |
| barcode   | string(32)| No       | Barcode from customers' app |
| memo      | string(128) | Yes    | Goods name |
| out\_trade\_no | string(32) | No      | Order number, should be unique, recommend using date(YYYYmmddHHiiss) + 18 digit random number |
| pay_type   | string(8) | No       | Pay type, IE0014 = ‘barcode alipay’; IE0024 = ‘barcode wechat’ |
| sign       | string(32) | No       | md5(mid=xxx&tid=xxx&fee=xxx&barcode=xxx&memo=xxx&out_trade_no=xxx&pay_type=xxx&key), please refer to <a href="#signature">signature explaination</a> section|

##### Return success
```
{
    "code": "200",
    "msg": "SUCCESS",
    "data": {
        "id": "60682",
        "mid": "10209",
        "tid": "0",
        "status": "1",
        "currency": "NZD",
        "amount": "0.01",
        "rate": "1.2",
        "customer_id": "64-2****70117",
        "goods_detail": "test",
        "out_trade_no": "s123411a2311232131332131",
        "trade_no": "2018061121001004210581551337",
        "payment_time": "2018-06-11 12:15:35"
    },
    "timestamp": 1528690537
}

```

##### Return error

```
'code':'1002' = PRICE_ERROR
'code':'1003' = SIGN_ERROR  
'code':'1004' = ORDER_NUMBER_EXIST / ORDER_CREATED
'code':'206' = SYSTEM_ERROR  
'code':'202' = WAITING_FOR_CUSTOMER_COMFIRM / UNPAID
'code':'205' = AUTH_CODE_INVALID / FAIL
```



#### 2. Payment check Interface

##### The gateway URL: https://mypay.iemoney.co.nz/api/check
##### Request Method: POST

| Parameter | Type   | Nullable | Description |
| --------- | ----   | -------- | ----------- |
| mid       | int(4) | Yes       | Merchant ID |
| pay_type  | string(8) | No     | Pay type, IE0014 = ‘barcode alipay’; IE0024 = ‘barcode wechat’ |
| out\_trade\_no | string(32) | No   | Order number |
| sign   | string(32) | Yes       | Signature |

##### return
```
'code':'1003' = SIGN_ERROR
'code':'1004' = TRADE_NO_ERROR
'code':'200' = SUCCESS  
'code':'208' = UNPAID 
```

***We recommend using polling to check payment, e.g. every 5 seconds***


#### 3. Refund Interface

##### The gateway URL: https://mypay.iemoney.co.nz/api/refund
##### Request Method: POST

| Parameter | Type   | Nullable | Description |
| --------- | ----   | -------- | ----------- |
| mid       | int(4) | Yes       | Merchant ID |
| pay_type  | string(8) | No     | Pay type, IE0014 = ‘barcode alipay’; IE0024 = ‘barcode wechat’ |
| out\_trade\_no | string(32) | No   | Order number |
| reference      | string(128) | Yes    | refund memo |
| refund_amount  | int(10)| No  | refund amount, unit: cent |
| sign   | string(32) | Yes       | Signature, please refer to <a href="#signature">signature explaination</a> section |

##### return
```
'code':'200' = SUCCESS  
'code':'1003' = SIGN_ERROR
'code':'1044' = OTHER
```


## Supplied Material

Barcode Scanner
![](https://i.ebayimg.com/images/g/nZQAAOSwmRFaXu5i/s-l300.jpg)


## <p id="signature">Signature explaination</p>

**Digital Algorithm**  
**Generate Pre-sign String**  
**Parameters to Sign**

In the list of request and response parameters, all of them need to be signed except sign and sign_type. (sign_type also needs to be signed in some cases in the list of request parameters)

Generate pre-sign string
For following data set：

```
string[] parameters={
  "mid=10209",
  "pay_type=IE0014",
  "refund_amount=1",
  "out_trade_no=20180402112304123210122312",
  "out_trade_no=6741334835157966",
  "reference='refund memo'"
  };
```
Rearrange parameters in the data set alphabetically
And connect rearranged parameters with &：

```
mid=10224&out_trade_no=20180402112304123210122312&pay_type=IE0014&reference=refund memo&refund_amount=1
```
**This is the pre-sign string.**
*** Note: ***
* Parameters without a value, must be included from sign;
* Charset in sign must be consistent with the charset used previously
* If _input_charset is passed, it also shall be signed.
According to HTTP protocol, special character like &,@ needs URL encoding, therefore the request receiver can get correct value. In this situation, pre-sign string shall be the original value instead of the encoded one. For example: calling a particular API need to sign the parameter email, the pre-sign string shall be email=test@msn.com, rather than email=test%40msn.com.
Signature Generation

**MD5 Signature**

Private Key is necessary for MD5 signature. The MD5 private key is the 32-byte string which is composed of English letters and numbers. Partner can log on the Merchant Service Center (<a href="https://mypay.iemoney.co.nz">https://mypay.iemoney.co.nz</a>) to check the private key.

**Sign for request**

After the partner receives the pre-sign string during requesting, the private key should be appended to the pre-sign string to generate the new string. Then this new string would be calculated with the MD5 signature algorithm by the MD5 signature function. Thus, the result 32-byte string is the signature result string. (the value is given to parameter “sign”)  


**result:**

Sign = Md5(PRE SIGN + API KEY)

```
example:
md5(mid=10224&out_trade_no=20180402112304123210122312&pay_type=IE0014&reference=refund memo&refund_amount=1e560fb2e61e4d1fe6a11c278388cb965)

result:
f45a1a2db58b43b48d51ab2fc18e0914
```

