# Install the Python Requests library:
# `pip install requests`

import requests


def send_request():
    # check
    # POST https://mypay.iemoney.co.nz/api/check

    try:
        response = requests.post(
            url="https://mypay.iemoney.co.nz/api/check",
            headers={
                "Cookie": "ci_session=al5totjh2hirgtlr9thsca3n0hagngt7",
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
            },
            data={
                "pay_type": "IE0014",
                "sign": "2ece67c650ec0f48b76c5351a9eb0771",
                "mid": "10224",
                "out_trade_no": "201804021123041232101231",
            },
        )
        print('Response HTTP Status Code: {status_code}'.format(
            status_code=response.status_code))
        print('Response HTTP Response Body: {content}'.format(
            content=response.content))
    except requests.exceptions.RequestException:
        print('HTTP Request failed')


