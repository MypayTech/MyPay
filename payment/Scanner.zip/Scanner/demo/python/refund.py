# Install the Python Requests library:
# `pip install requests`

import requests


def send_request():
    # refund
    # POST https://mypay.iemoney.co.nz/api/refund_order

    try:
        response = requests.post(
            url="https://mypay.iemoney.co.nz/api/refund",
            headers={
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
            },
            data={
                "pay_type": "IE0014",
                "sign": "f45a1a2db58b43b48d51ab2fc18e0914",
                "mid": "10224",
                "reference": "refund memo",
                "out_trade_no": "20180402112304123210122312",
                "refund_amount": "1",
            },
        )
        print('Response HTTP Status Code: {status_code}'.format(
            status_code=response.status_code))
        print('Response HTTP Response Body: {content}'.format(
            content=response.content))
    except requests.exceptions.RequestException:
        print('HTTP Request failed')


