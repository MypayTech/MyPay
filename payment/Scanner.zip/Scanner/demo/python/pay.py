# Install the Python Requests library:
# `pip install requests`

import requests


def send_request():
    # pay
    # POST https://mypay.iemoney.co.nz/api/pay

    try:
        response = requests.post(
            url="https://mypay.iemoney.co.nz/api/pay",
            headers={
                "Cookie": "ci_session=al5totjh2hirgtlr9thsca3n0hagngt7",
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
            },
            data={
                "barcode": "289920144547400074",
                "mid": "10224",
                "memo": "test",
                "pay_type": "IE0014",
                "fee": "1",
                "sign": "b1f85f02ad880d921ca1a4555e0c26f9",
                "tid": "0",
                "out_trade_no": "20180402112304123210122312",
            },
        )
        print('Response HTTP Status Code: {status_code}'.format(
            status_code=response.status_code))
        print('Response HTTP Response Body: {content}'.format(
            content=response.content))
    except requests.exceptions.RequestException:
        print('HTTP Request failed')


