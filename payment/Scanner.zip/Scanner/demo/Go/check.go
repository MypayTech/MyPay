package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"bytes"
)

func sendPay() {
	// pay (POST https://mypay.iemoney.co.nz/api/pay)

	params := url.Values{}
	params.Set("barcode", "289920144547400074")
	params.Set("mid", "10224")
	params.Set("memo", "test")
	params.Set("pay_type", "IE0014")
	params.Set("sid", "0")
	params.Set("fee", "1")
	params.Set("sign", "b1f85f02ad880d921ca1a4555e0c26f9")
	params.Set("tid", "0")
	params.Set("out_trade_no", "20180402112304123210122312")
	body := bytes.NewBufferString(params.Encode())

	// Create client
	client := &http.Client{}

	// Create request
	req, err := http.NewRequest("POST", "https://mypay.iemoney.co.nz/api/pay", body)

	// Headers
	req.Header.Add("Cookie", "ci_session=al5totjh2hirgtlr9thsca3n0hagngt7")
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")

	// Fetch Request
	resp, err := client.Do(req)
	
	if err != nil {
		fmt.Println("Failure : ", err)
	}

	// Read Response Body
	respBody, _ := ioutil.ReadAll(resp.Body)

	// Display Results
	fmt.Println("response Status : ", resp.Status)
	fmt.Println("response Headers : ", resp.Header)
	fmt.Println("response Body : ", string(respBody))
}


