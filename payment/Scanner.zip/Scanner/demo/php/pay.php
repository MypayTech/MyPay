<?php

// Get from MyPay System
define("API_KEY", "e560fb2e61e4d1fe6a11c278388cb965");
define("MID", "10224");

// get cURL resource
$ch = curl_init();

// set url
curl_setopt($ch, CURLOPT_URL, 'https://mypay.iemoney.co.nz/api/pay');
// curl_setopt($ch, CURLOPT_URL, 'http://sandbox.mypaynz.com/api/pay');

// set method
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

// return the transfer as a string
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// set headers
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
]);

// json body
$body = [
  'mid' => MID,
  'tid' => '0',
  'fee' => 100000,
  'barcode' => '283276718893s8356310015',
  'memo' => 'health prouct test from fans',
  'out_trade_no' => '20181005165151ds9839v52x',
  'pay_type' => 'IE0014'
];

function sign($parameters, $key) {
	ksort($parameters);
	$string = '';
	foreach ($parameters as $k=>$v) {
		$string .= $k . '=' . $v;
		$string .= '&';
	}
	$string = substr($string, 0, -1);
	return md5($string . $key);
}

$body['sign'] = sign($body, API_KEY);
$body = http_build_query($body);

// set body
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);

// send the request and save response to $response
$response = curl_exec($ch);

// stop if fails
if (!$response) {
  die('Error: "' . curl_error($ch) . '" - Code: ' . curl_errno($ch));
}

echo 'HTTP Status Code: ' . curl_getinfo($ch, CURLINFO_HTTP_CODE) . PHP_EOL;
echo 'Response Body: ' . $response . PHP_EOL;

// close curl resource to free up system resources 
curl_close($ch);


