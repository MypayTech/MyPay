using System;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Text;

namespace MyNamespace {
	public class MyActivity {
		
		private async Task<bool> pay () {

			string url = "https://mypay.iemoney.co.nz/api/pay";

			HttpWebRequest request = (HttpWebRequest)WebRequest.Create (new Uri(url));
			request.ContentType = "application/x-www-form-urlencoded; charset=utf-8";
			request.Headers.Add("Cookie", "ci_session=al5totjh2hirgtlr9thsca3n0hagngt7");
			
			request.Method = "POST";
			
			string postData = "mid=10224&tid=0&fee=1&barcode=289920144547400074&memo=test&pay_type=IE0014&out_trade_no=20180402112304123210122312&sign=b1f85f02ad880d921ca1a4555e0c26f9";
			ASCIIEncoding encoding = new ASCIIEncoding ();
			byte[] byte1 = encoding.GetBytes (postData);
			request.ContentLength = byte1.Length;
			Stream newStream = request.GetRequestStream ();
			newStream.Write (byte1, 0, byte1.Length);
			newStream.Close ();
			
			using (WebResponse response = await request.GetResponseAsync ()) {
				using (Stream stream = response.GetResponseStream ()) {
					return true;
					//process the response
				}
			}
		}
	}
}
