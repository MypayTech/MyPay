## API List
### 1. Create Order Interface

The gateway URL： https://mypay.iemoney.co.nz/api/online<br>
Request Method: POST

| Parameter | Type   | Nullable | Description |
| --------- | ----   | -------- | ----------- |
| mid       | int(4) | No       | Merchant ID |
| tid       | int(4) | No       | Terminal ID |
| total_fee | int(10)| No       | Amount, Unit: Cent |
| rmb_fee   | int(10)| Yes      | Amount, Unit: Cent. Only used when pay_type is IE0012 or IE0013. Use this parameter to replace total_fee if partner wish to price their product in RMB. If total_fee is used, rmb_fee should not be set. They are mutual exclusive. |
| goods     | string(64) | No   | Item name, must not contain any special characters |
| goods_detail | string(128) | No | Item descripion, must not contain any special characters |
| out\_trade\_no | string(64) | No      | Order number, should be unique, recommend using date(YYYYmmddHHiiss) + 18 digit random number |
| pay_type   | string(8) | No   | **IE0011** = qrcode\_alipay;<br> **IE0012** = web\_alipay;<br> **IE0013** = wap\_alipay;<br> **IE0015** = app\_alipay;<br> **IE0021** = qrcode\_wechat;<br> **IE0022** = wap\_wechat;<br> **IE0025** = app\_wechat;<br> **IE0031** = UNION;<br> **IE0041** = POLI; |
| expired   | int(8) | Yes   | Expiration time, Unit: second. default: 3600|
| return_url | string(512)| Yes | After the payment is done, the result is returned to this url via the URL redirect.|
| notify_url | string(512)| Yes | The URL for receiving asynchronous notifications after the payment is done. |
| version   | string(4)   | No  | 'v1'|
| pay_rate  | int(4)| Yes       | Default merchant rate if null, range 0 - 30 |
| sign       | string(32) | No  | Signature, please refer to <a href="#signature">signature explaination</a> section |

##### Return Success
```
{
    "is_success": "TRUE",
    "message": "SUCCESS",
    "extra": {
        "mid": "10224",
        "pay_type": "IE0012",
        "out_trade_no": "201808170123245622346777231",
        "pay_url": "https://intlmapi.alipay.com/gateway.do?_input_charset=utf-8&currency=NZD&notify_url=https://mypay.iemoney.co.nz/api/alipay_push_notify_web&order_gmt_create=2018-07-26 07:00:27&order_valid_time=3600&out_trade_no=201808170123245622346777231&partner=2088421400772571&return_url=http://www.amazon.com/syn&secondary_merchant_id=10224&secondary_merchant_industry=0742&secondary_merchant_name=merchant&service=create_forex_trade&subject=123312&supplier=merchant&total_fee=1&sign_type=MD5&sign=da41c17de81b5981d376a1b32c382d04"
    }
}

```

##### Return Fail
```
{
    "is_success": "FALSE",
    "message": "ORDER_CREATED",
    "extra": {
        "mid": "10224",
        "pay_url": "https://intlmapi.alipay.com/gateway.do?_input_charset=utf-8&currency=NZD&notify_url=https://mypay.iemoney.co.nz/api/alipay_push_notify_web&order_gmt_create=2018-07-26 07:03:43&order_valid_time=3600&out_trade_no=2018081701232456223467772311&partner=2088421400772571&return_url=http://www.amazon.com/syn&rmb_fee=0.12&secondary_merchant_id=10224&secondary_merchant_industry=0742&secondary_merchant_name=merchant&service=create_forex_trade&subject=123312&supplier=merchant&sign_type=MD5&sign=be411b88522a162290bf4f45412d43ad",
        "pay_type": "IE0012",
        "out_trade_no": "2018081701232456223467772311"
    }
}
```

#### Synchronized result notification

Once payment succeed, there will be a synchronize notification which redirect end user to return_url. it's recommended sync notification only be used for user interaction. All variable passed to API https://mypay.iemoney.co.nz/api/online will be also returned.
```
$url = $return_url 
```

#### Asynchronized result notification
merchant need to return 'SUCCESS' once they received asyc notification. otherwise mypay will keep sending asyc notification for 12 hours.
Please note it is possible you get more than one notification at the same time so please make sure the order number is unique.
```
$url = $notify_url."?out_trade_no=".$out_trade_no."&trade_no=".$trade_no."&trade_status=SUCCESS&pay_type=".$pay_type."&sign=".$sign;

$sign = md5($trade_no.$out_trade_no.'SUCCESS'.$api_key);
```


### 2. Check Order Interface

The gateway URL: https://mypay.iemoney.co.nz/api/check\_order\_status<br>
Request Method: POST

| Parameter | Type   | Nullable | Description |
| --------- | ----   | -------- | ----------- |
| mid       | int(4) | No      | Merchant ID |
| pay_type  | string(8) | No    | **IE0011** = qrcode\_alipay;<br> **IE0012** = web\_alipay;<br> **IE0013** = wap\_alipay;<br> **IE0015** = app\_alipay;<br> **IE0021** = qrcode\_wechat;<br> **IE0022** = wap\_wechat;<br> **IE0025** = app\_wechat;<br> **IE0031** = UNION;<br> **IE0041** = POLI; |
| out\_trade\_no | string(64) | No   | Order number |
| version   | string(4) | No   | 'v1' |
| sign   | string(32) | No      | Signature, please refer to <a href="#signature">signature explaination</a> section |

##### return
```
{
    'is_success':'FALSE'
    'message': 'SIGN_ERROR'
}
{
    'is_success':'FALSE'
    'message': 'COMBINE_ERROR'
}
{
    'is_success':'TRUE'
    'message': 'SUCCESS',
    'extra': {
        'pay_type': 'IE0011'
        'trade_no' : '201809191132544236',
        'out_trade_no' :'20180919113254423851060785271346',
        'order_status' :'0',
        'total_fee' :'1.5',
        'goods' : 'goods',
        'pay_url' : 'https://qr.alipay.com/bax08230wcpl6ihwsmfd40d0',
        'return_url' :'****'
    }
} 
```


##### Order Status :

* 0 : UNPAY;
* 1 = PAID;
* 2 = REFUND;
* 3 = SETTLED;

### 3. Refund Order Interface

The gateway URL: https://mypay.iemoney.co.nz/api/refund<br>
Request Method: POST

| Parameter | Type   | Nullable | Description |
| --------- | ----   | -------- | ----------- |
| mid       | int(4) | No      | Merchant ID |
| out\_trade\_no | string(64) | No   | Order number |
| pay_type  | string(8) | No     | **IE0011** = qrcode\_alipay;<br> **IE0012** = web\_alipay;<br> **IE0013** = wap\_alipay;<br> **IE0015** = app\_alipay;<br> **IE0021** = qrcode\_wechat;<br> **IE0022** = wap\_wechat;<br> **IE0025** = app\_wechat;<br> **IE0031** = UNION;<br> **IE0041** = POLI; |
| refund_amount  | int(10)| No  | Refund Amount, Unit: Cent |
| version   | string(4) | No   | 'v1' |
| sign      | string(32) | No      | Signature, please refer to <a href="#signature">signature explaination</a> section |

##### return
```
{
    'is_success':'FALSE',
    'message': 'SIGN_ERROR'
}
{
    'is_success':'FALSE',
    'message': 'ERROR_PAYMENT_STATUS'
}
{
    'is_success':'TRUE',
    'message': 'SUCCESS' 
}
```



### <p id="signature">4.Signature explaination</p>


**Parameters to Sign**

In the list of request and response parameters, all of them need to be signed except sign and sign_type. (sign_type also needs to be signed in some cases in the list of request parameters)

Generate pre-sign string
For following data set：

```
string[] parameters={
  "mid=10209",
  "pay_type=IE0014",
  "refund_amount=1",
  "out_trade_no=20180402112304123210122312",
  "out_trade_no=6741334835157966",
  "reference='refund memo'"
  };
```
Rearrange parameters in the data set alphabetically
and connect rearranged parameters with &：

```
mid=10224&out_trade_no=20180402112304123210122312&pay_type=IE0014&reference=refund memo&refund_amount=1
```
**This is the pre-sign string.**
*** Note: ***
* Parameters without a value, must be included from sign;
* Charset in sign must be consistent with the charset used previously
* If _input_charset is passed, it also shall be signed.
According to HTTP protocol, special character like &,@ needs URL encoding, therefore the request receiver can get correct value. In this situation, pre-sign string shall be the original value instead of the encoded one. For example: calling a particular API need to sign the parameter email, the pre-sign string shall be email=test@msn.com, rather than email=test%40msn.com.
Signature Generation

**MD5 Signature**

Private Key is necessary for MD5 signature. The MD5 private key is the 32-byte string which is composed of English letters and numbers. Partner can log on the Merchant Service Center (<a href="https://mypay.iemoney.co.nz">https://mypay.iemoney.co.nz</a>) to check the private key.

**Sign for request**

After the partner receives the pre-sign string during requesting, the private key should be appended to the pre-sign string to generate the new string. Then this new string would be calculated with the MD5 signature algorithm by the MD5 signature function. Thus, the result 32-byte string is the signature result string. (the value is given to parameter “sign”)  


**result:**

Sign = Md5(PRE SIGN + API KEY)

```
example:
md5(mid=10224&out_trade_no=20180402112304123210122312&pay_type=IE0014&reference=refund memo&refund_amount=1e560fb2e61e4d1fe6a11c278388cb965)

result:
f45a1a2db58b43b48d51ab2fc18e0914
```
