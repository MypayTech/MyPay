## MYPAY New Zealand  

**For Alipay and WeChat Pay payment services**

Test Account:

```
Test Account:
* User : merchant_test
* Passwordw: 123456
* MID : 10224
* Api Key : e560fb2e61e4d1fe6a11c278388cb965
```

Production Environment:

```
https://mypay.iemoney.co.nz
```

Contact Developer:

```
* Email   horton@iemoney.co.nz
* Wechat  adlomac
* Slack   horton@iemoney.co.nz
```